//
//  TestViewModel.swift
//  DemoAppTests
//
//  Created by Selma Dsouza (Digital) on 28/11/19.
//  Copyright © 2019 Santanu Koley(Digital). All rights reserved.
//

import XCTest
import UIKit
@testable import DemoApp

class TestViewModel: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    func testAPI(){
        // This is an example of a functional test case.
        guard let gitUrl = URL(string: "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json") else { return }
        let promise = expectation(description: "Simple Request")
        URLSession.shared.dataTask(with: gitUrl) { (data, response
            , error) in
            guard let data = data else { return }

                let responseStrInISOLatin = String(data: data, encoding: String.Encoding.isoLatin1)
                guard let modifiedDataInUTF8Format = responseStrInISOLatin?.data(using: String.Encoding.utf8) else {
                    print("could not convert data to UTF-8 format")
                    return
                }
                do {
                    let decoder = JSONDecoder()
                    let results = try decoder.decode(Model_Base.self, from: modifiedDataInUTF8Format)
                    XCTAssertTrue(results.title!.count > 0)
                    XCTAssertTrue(results.rows.count > 0)
                    promise.fulfill()
                } catch {
                    print(error)
                }
            }.resume()
        waitForExpectations(timeout: 10, handler: nil)
    }

}
